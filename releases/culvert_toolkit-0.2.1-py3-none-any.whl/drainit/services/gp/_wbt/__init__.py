from ....models import WorkflowConfig

class GP:

    def __init__(self, workflow_config: WorkflowConfig):
        self.cfg = workflow_config